'use strict';

class BinaryTree {
	constructor() {

	}

	insert(data) {

	}

	contains(data) {

	}

	remove(data) {

	}

	size() {

	}

	isEmpty() {

	}
}
'use strict';
